TO RUN THE RESEARCH ANALYZER:

NOTE: Must be run with Windows 10

1. Go to Kingston University's Research Database on Wrap (eprints)
2. Select 'Browse by Year'
3. Select 2018
4. Export as JSON
	If using CHROME
		Ctrl + A to select all then
		Ctrl + C to copy
		Open a text editor, Notepad
		Ctrl + v to paste
		Save file as 'research.json' in the same folder as this file

	If using firefox
		Select 'Save'
		Save the file as 'research.json' in the same folder as this file
5. Open the ResearchAnalyzer file
6. Record percentages as part of the research questionnaire in respective questions
			

