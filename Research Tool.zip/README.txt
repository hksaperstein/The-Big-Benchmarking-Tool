TO RUN THE RESEARCH ANALYZER:

NOTE: Must be run with Windows 10 and on FIREFOX

1. Go to Kingston University's Research Database on Wrap (eprints)
2. Select 'Browse by Year'
3. Select 2018
4. Select "Export as: JSON"
5. Press Export
6. Select 'Save'

7. Change file type to "all fies(*.*) and save the file as 'research.json' in the same folder as this file

5. Open the ResearchAnalyzer.exe file
	If prompted, press "continue" to run
6. Record percentages as part of the research questionnaire in respective questions
			

