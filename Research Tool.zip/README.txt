TO RUN THE RESEARCH ANALYZER:

NOTE: Must be run with Windows 10


DOWNLOADING THE RESEARCH JSON AND RUNNING THE PROGRAM

1. Go to Kingston University's Research Database on Wrap (eprints)
2. Select 'Browse by Year'
3. Select 2018
4. Select "Export as: JSON"
5. Press Export
6. Saving the File
	If in CHROME:
		Right-click and press 'Save', this will take a moment or two for the file explorer to open
		Once the file explorer is open:
			Change file type to 'all files'
			Name file 'research.json'
			Save the file in the same folder as this file
	If in FIREFOX
		Press'save'button (top-left corner)
		Once the file explorer is open:
			Change file type to 'all files'
			Name file 'research.json'
			Save the file in the same folder as this file
7. Open folder with ResearchAnalyzer.exe 

8. Open the ResearchAnalyzer.exe file (double-click)
	If prompted, press "continue" to run 
9. Record percentages as part of the research questionnaire in respective questions
			

