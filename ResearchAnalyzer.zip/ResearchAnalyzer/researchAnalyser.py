# This is a script that will analyze a json produced by the University of worcester's WRAP database
import sys
import json
import os
import re

# Setup keyword regex
keywordList = ["\\bDeveloping Countries", "Economic Resources", "Equality", "Financial Inclusion", "Income Equality", "Inequality", "Overuse Of Resource", "Poverty", "Quality Of Life", "Resource Efficiency", "Resource Overuse", "Third World", "Vulnerable", "Wealth Distribution", "Consumption of Resources", "Food Gap", "Food Reserves", "Food Security", "Hunger", "Hungry People", "Malnutrition", "Nutrition", "Resource Consumption", "Rural Infrastructure", "Sustainable Agriculture", "Air Contamination", "Air Pollution", "Child Deaths", "Clean Water", "Disability", "Healthy Living", "International Health Policy", "International Health Regulations", "Reducing Malaria", "Reducing Mortality", "Soil Contamination", "Soil Pollution", "Treatment Of Substance Abuse", "Well Being", "Wellbeing", "Well-Being", "Access To Education", "Basic Literacy", "Equal Education", "Equitable Education", "Gender Disparities In Education", "Gender Disparity", "Gender Equality", "Gender Equity", "Gender Sensitive", "Inclusive Education", "Opportunities For All", "Refugees And Learning", "Universal Education", "Disadvantaged", "Discrimination", "Empower women", "Empowering Girls", "Empowering Women", "Empowerment Of Girls", "Empowerment Of Women", "Equal Access", "Exploitation", "Female Empowerment", "Female Genital Mutilation", "Feminism", "Forced Marriage", "Gender Discrimination", "Gender equality", "Human Rights", "Human Trafficking", "Humanitarian", "Marginalised", "Reproductive Health", "Reproductive Rights", "Sexual Health", "Sexual Violence", "Social Inclusion", "Unemployment", "Universal Health Coverage", "Violence Against Girls", "Violence Against Women", "Women Empowerment", "Women’s Rights", "Workplace Equality", "Accessible Water", "Affordable Drinking Water", "Contaminated", "Contamination", "Ecosystem Protection", "Ecosystem Restoration", "Equitable Sanitation", "Hydropower", "Improving Water", "Inadequate Water", "Pollution", "Recycle", "Safe Drinking Water", "Sanitation", "Water Access", "Water Disasters", "Water Ecosystems", "Water Efficiency", "Water Harvesting", "Water Quality", "Water Resources Management", "Water Scarcity", "Water Supply", "Water-related Ecosystems", "Water-use Efficiency", "Affordable Energy", "Alternative Energy", "Fossil Fuel", "Fossil-fuel", "Green Economy", "Greenhouse Gas", "Greenhouse Gas Emissions", "Hydroelectric", "Low Carbon", "Reliable Energy", "Renewable", "Solar Energy", "Solar Power", "Sustainable Energy", "Wave Energy", "Wave Power", "Wind Energy", "Wind Power", "Decent Work", "Economic growth", "Equal Pay", "Global Resource Efficiency", "Productive employment", "Sustainable Economic Growth", "Sustainable Growth", "Foster innovation", "Infrastructure", "Resilient Infrastructure", "Resource Use Efficiency", "Sustainable Industrialization", "Water Resources", "Ageism", "Discriminatory", "Equal Opportunity", "Racism", "Reduce Inequality", "Sexism", "Classism", "Air Quality", "Climate Change", "Disaster Management", "Disaster Risk Reduction", "Human settlements", "Inadequate Housing", "Inclusive Cities", "Inclusive human Settlements", "Land Consumption", "Resource Needs", "Smart Cities", "Waste Generation", "Waste Management", "Decarbonisation", "Efficient Use Of Resources", "Energy Consumption", "Energy Efficiency", "Energy Use", "Food Losses", "Food Supply", "Food Waste", "Future Proof", "Greenhouse Gasses", "Natural Resources", "Productive Patterns", "Recycling", "Reduce Waste Generation", "Reduction", "Sustainable Consumption", "Water Pollution", "Climate Action", "Climate change", "Climate Change Planning", "Climate Change Policy", "Cop 21", "Cop 22", "Emissions", "Extreme Weather", "Global Mean Temperature", "Global Temperature", "Global Warming", "Greenhouse Gases", "Ice Loss", "Low-carbon Economy", "Ocean Systems", "Paris Agreement", "Rising Sea", "Sea Level Rise", "Conservation", "Conserve", "Conserve Oceans", "Ecosystem Management", "Marine", "Ocean Acidification", "Ocean Temperature", "Oceans", "Protected Areas", "Seas", "Sustainable Oceans", "Biodiversity", "Deforestation", "Desertification", "Desertifications", "Ecosystems", "Illegal Wildlife Products", "Land Conservation", "Land Degradation", "Land Loss", "Land Use And Sustainability", "Manage Forests", "Protected Fauna", "Protected Flora", "Protected Species", "Reforestation", "Soil Degradation", "Terrestrial Ecosystems", "Threatened Species", "Access to Justice", "Accountable Institutions", "Hate Crime", "Inclusive Institutions", "Inclusive Societies", "Peace", "Peaceful Societies", "Doha Development Agenda", "Environmentally Sound Technologies", "Global Partnership", "Global Partnerships For Sustainable Development", "International Cooperation", "International Support", "Poverty Eradication", "Sustainability", "Sustainable", "Women Entrepreneurs", "Active Lifestyle", "Adolescent Development", "Baby Development", "Child Development", "Consumption of Fossil Fuel", "Consumption Of Natural Resource", "Consumption Of Resource", "Ecological System", "Economic Instability", "Economic Sustainability", "Education Sector", "Enabling Environments", "Environmental Assessment", "Environmental Degradation", "Environmental Issue", "Environmental Policy", "Environmental Sustainability", "Environmentally Sensitive", "Environmentally-sensitive", "Equal Rights To Economic Resources", "Future Policy", "Habitat Quality", "Human Well-being", "Impoverished", "Inclusion", "Justice Legislation", "Justice Sector", "Land Use", "Marginalization", "Mental Health", "Natural Environment", "Natural Hazards", "Poverty Reduction", "Resource Management", "Safe Communities", "SDG", "Segregation", "Social Sustainability", "Special Education", "Supporting Families", "Sustainable Development", "Sustainable Education", "Sustainable Livelihood", "Vulnerable Species", "Women Equality", "Women Rights\\b"]
keywordRegex = re.compile('\\b|\\b'.join(keywordList), flags=re.I|re.U)

# Json File from database
file_name = "research/k2017.json"
if(len(sys.argv) > 1):
    file_name = sys.argv[1]

# Get the json from the file
rjson = json.load(open(file_name, 'r', encoding="utf-8"))
print(rjson)
print("Loaded Json")

# TSV file for research output
rtsv = open("researchAnalyzed.tsv", 'w', encoding="utf-8")
rtsv.write('Title\tAbstract\tKeywords\n')

ortsv = open("otherResearchAnalyzed.tsv", 'w', encoding="utf-8")
ortsv.write('Title\tAbstract\n')

# Accumulators
articles = 0
susArticles = 0
total = 0
skipped = 0
susAuthors = []
allAuthors = []

# For all the results in the json

#robj is a key in a dictionary

for robj in rjson:
    try:
        total+=1
        if 'rioxx2_title' in rjson:
            rTitle = robj['rioxx2_title'].replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        else:
            rTitle = robj['title'].replace('\n',' ').replace('\r',' ').replace('\t', ' ')

        if 'rioxx2_description' in rjson:
            rAbs = robj['rioxx2_description'].replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        elif 'abstract' in rjson:
            rAbs = robj['abstract'].replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        else:
            rAbs = None

        # Count only after possible failure to find title/abstract
        articles+=1

        # Get all the authors into a list
        creators = []
        for auth in robj["creators"]:
            aLast = auth["name"]["family"]
            aFirst = auth["name"]["given"]
            if(aLast and aFirst):
                creators.append(aLast +", "+ aFirst)
            elif(aLast):
                creators.append(aLast)
        allAuthors += creators

        # If its got a keyword in the title or abstract
        if (keywordRegex.search(rTitle) or (rAbs is not None and keywordRegex.search(rAbs))):
            susArticles+=1
            # Get the list of keyword hits, and sort/remove duplicates
            matchesL = keywordRegex.findall(rTitle) + keywordRegex.findall(rAbs)
            matchesL = sorted(list(set([el.lower() for el in matchesL])))
            rtsv.write("{}\t{}\t{}\n".format(
                rTitle, rAbs, ','.join(matchesL)))
            susAuthors += creators
        else:
            ortsv.write("{}\t{}\n".format(rTitle, rAbs))

    except KeyError as e:
        # print(e)
        skipped+=1
        continue

rtsv.close()
ortsv.close()

susAuthors = sorted(list(set(susAuthors)))
allAuthors = sorted(list(set(allAuthors)))

# TSV file for authors
atsv = open("susAuthors.tsv", 'w', encoding="utf-8")
# Write authors
atsv.write('\n'.join(susAuthors))
atsv.close()

# Print Results
print("Done")
print("Found {} items".format(total))
print("Skipped {}".format(skipped))
print("Analyzed {} research articles".format(articles))
print("Found {} sustainability research articles".format(susArticles))
print("Found {} authors, {} writing sustainability related articles"
      .format(len(allAuthors), len(susAuthors)))
